<?php

namespace App\Http\Controllers\Admin;

use App\Models\Lapangan;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\LapanganStoreRequest;
use App\Http\Requests\Admin\LapanganUpdateRequest;

class LapanganController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $lapangans = Lapangan::latest()->get();

        return view('admin.lapangans.index', compact('lapangans'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.lapangans.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        // dd($request->all());
        // if($request->validated()){
        //     $gambar = $request->file('gambar')->store('assets/lapangan', 'public');
            $slug = Str::slug($request->name_lapangan, '-');
        //     Lapangan::create($request->except('gambar') + ['gambar' => $gambar, 'slug' => $slug]);
        // }

        $data = new Lapangan();
        $data->nama_lapangan = $request->name_lapangan;
        $data->slug = $slug;
        $data->harga_sewa = $request->harga_sewa;
        $data->status = $request->status;
        $data->minuman = $request->minuman;
        $data->jumlah_lapangan = $request->jumlah_lapangan;
        $foto_file = $request->file('gambar');
        $foto_ekstensi = $foto_file->extension();
            $foto_nama = date('ymdhis') . "." . $foto_ekstensi;
            $foto_file->move(public_path('gambar'), $foto_nama);
            $data->gambar = $foto_nama;
            $data->save();

        return redirect()->route('lapangans.index')->with([
            'message' => 'Data Berhasil Dibuat',
            'alert-type' => 'success'
        ]);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit(Lapangan $lapangan)
    {
        return view('admin.lapangans.edit', compact('lapangan'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(LapanganUpdateRequest $request,Lapangan $lapangan)
    {
        if($request->validated()){
            $slug = Str::slug($request->nama_lapangan, '-');
            $lapangan->update($request->validated() + ['slug' => $slug]);
        }

        return redirect()->route('lapangans.index')->with([
            'message'=>'Data Berhasil Di Edit',
            'alert-type'=>'info'
        ]);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy(Lapangan $lapangan)
    {
        if($lapangan->gambar){
            unlink('gambar/'. $lapangan->gambar);
        }
        $lapangan->delete();

        return redirect()->back()->with([
            'message'=>'Data Berhasil Di Hapus',
            'alert-type' => 'danger'
        ]);
    }

    public function updateImage(Request $request, $lapanganId)
    {
        $request->validate([
            'gambar' => 'required|image'
        ]);
        $lapangan = Lapangan::findOrFail($lapanganId);
        if($request->gambar){
            unlink('storage/'. $lapangan->gambar);
            $gambar = $request->file('gambar')->store('assets/lapangan', 'public');

            $lapangan->update(['gambar' => $gambar]);
        }

        return redirect()->back()->with([
            'message' => 'Gambar Berhasil Di Edit',
            'alert-type' => 'info'
        ]);
    }
}
