@extends('layouts.admin')

@section('content')
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h3>Daftar Pesan</h3>
            {{--  <a href="/pesan/create" class="btn btn-primary">Tambah Data</a>  --}}
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama</th>
                            <th>Nomor Hp</th>
                            <th>Bukti Pembayaran</th>
                            <th>Lapangan</th>
                            <th>Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse ($data as $item)
                            <tr>
                                <td>{{$no++}}</td>
                                <td>{{$item->nama}}</td>
                                <td>{{$item->no_hp}}</td>
                                <td>
                                    @if ($item->bukti_pembayaran)

                                    <img src="{{ url('foto').'/'.$item->bukti_pembayaran }}" width="200" alt="">
                                    @endif
                                </td>
                                <td>{{$item->lapangan}}</td>
                                <td>Pending</td>
                            </tr>
                                @empty
                                    <tr>
                                         <td colspan="6" class="text-center">Data Kosong</td>
                                    </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@endsection
