@extends('layouts.admin')

@section('content')
    <div class="row">
        <div class="col-lg-8">
            <div class="card">
                <div class="card-header">
                    Form tambah Data
                </div>
                <div class="card-body">
                    <form action="{{ route('lapangans.store')}}" method="post" enctype="multipart/form-data">
                        @csrf
                        {{-- @method('put') --}}
                        <div class="form-group">
                            <label for="nama_lapangan">Nama Lapangan</label>
                            <input type="text" name="name_lapangan" class="form-control" value="{{ old('nama_lapangan')}}">
                        </div>
                        <div class="form-group">
                            <label for="harga_sewa">IDR Harga Sewa</label>
                            <input type="number" name="harga_sewa" class="form-control" value="{{ old('harga_sewa')}}">
                        </div>
                        <div class="form-group">
                            <label for="minuman">Minuman</label>
                            <input type="text" name="minuman" class="form-control" value="{{ old('minuman')}}">
                        </div>
                        <div class="form-group">
                            <label for="jumlah_lapangan">Jumlah Lapangan</label>
                            <input type="number" name="jumlah_lapangan" class="form-control" value="{{ old('jumlah_lapangan')}}">
                        </div>
                        <div class="form-group">
                            <label for="jenis_lapangan">Jenis Lapangan</label><br>
                            <input type="radio"  name="jenis_lapangan" class="form" value="Indoor" required="required"> Indoor <br>
                            <input type="radio" name="jenis_lapangan" class="form" value="Outdoor" required="required"> Outdoor <br>
                        </div>


                         <div class="form-group">
                            <label for="status">Status</label><br>
                            <input type="radio" name="status" class="form" value="Full" required="required"> Full<br>
                            <input type="radio"  name="status" class="form" value="Tersedia" required="required"> Tersedia<br>
                        </div>
                        <div class="form-group">
                            <label for="deskripsi">Deskripsi</label>
                            <textarea name="deskripsi" class="form-control" id="deskripsi" cols="30" rows="5">{{old ('deskripsi')}}</textarea>
                        </div>
                        <div class="form-group">
                            <label for="jaring">Jaring</label><br>
                            <input type="radio" name="jaring" class="form" value="1" required="required"> Tersedia <br>
                            <input type="radio" name="jaring" class="form" value="0" required="required"> Tidak Tersedia <br>
                        </div>
                        <div class="form-group">
                            <label for="lampu">Lampu</label><br>
                            <input type="radio"  name="lampu" class="form" value="1" required="required"> Tersedia <br>
                            <input type="radio" name="lampu" class="form" value="0" required="required"> Tidak Tersedia <br>
                        </div>
                        <div class="form-group">
                            <label for="speaker">Speaker</label><br>
                            <input type="radio"  name="speaker" class="form" value="1" required="required"> Tersedia <br>
                            <input type="radio" name="speaker" class="form" value="0" required="required"> Tidak Tersedia <br>
                        </div>
                        <div class="form-group">
                            <label for="bola">Bola</label><br>
                            <input type="radio" name="bola" class="form" value="1" required="required"> Tersedia <br>
                            <input type="radio"  name="bola" class="form" value="0" required="required">Tidak Tersedia <br>
                        </div>
                        <div class="form-group">
                            <label for="gambar">Gambar</label>
                            <input type="file" class="form-control" name="gambar">
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-primary">Simpan</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
        {{-- <div class="card">
                <div class="card-header">
                    Form tambah Gambar
                </div>
                <div class="card-body">
                    <form action="" method="post" enctype="multipart/form-data">
                        @csrf
                        @method('put')
                        <div class="form-group">
                            <img src=""  class="img-fluid" alt="">
                        </div>
                        <div class="form-group">
                            <label for="gambar">Gambar</label>
                            <input type="file" class="form-control" name="gambar">
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-primary">Simpan</button>
                        </div>
                    </form>
                </div>
            </div>
        </div> --}}
    </div>
@endsection
