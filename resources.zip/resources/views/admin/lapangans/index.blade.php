@extends('layouts.admin')

@section('content')
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h3>Daftar Lapangan</h3>
            <a href="{{ route('lapangans.create') }}" class="btn btn-primary">Tambah Data</a>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama Lapangan</th>
                            <th>Gambar Lapangan</th>
                            <th>Harga lapangan</th>
                            <th>Status Lapangan</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($lapangans as $lapangan)
                            <tr>
                                <td> {{ $loop->iteration }}</td>
                                <td> {{ $lapangan->nama_lapangan }}</td>
                                <td>
                                    <img src="/gambar/{{$lapangan->gambar}}" width="200" alt="">
                                </td>
                                <td> {{ $lapangan->harga_sewa }}</td>
                                <td> {{ $lapangan->status }}</td>
                                <td>
                                    <a href="{{ route('lapangans.edit', $lapangan->id) }}" class="btn btn-sm btn-warning">Edit</a>
                                    <form onclick="return conrifm('anda yakin ingin menghapus?');" class="d-inline" action="{{ route('lapangans.destroy', $lapangan->id) }}" method="post">
                                        @csrf
                                        @method('delete')
                                        <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="6" class="text-center">Data Kosong</td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@endsection