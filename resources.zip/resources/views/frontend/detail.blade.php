@extends('layouts.frontend')

@section('content')
<header class="bg-dark py-5">
    <div class="container px-4 px-lg-5 my-5">
      <div class="text-center text-white">
        <h1 class="display-4 fw-bolder">Detail Lapangan</h1>
      </div>
    </div>
  </header>
  <!-- Section-->
  <section class="py-5">
    <div class="container px-4 px-lg-5 mt-5">
      <div class="row justify-content-center">
        <div class="col-lg-8 mb-5">
          <div class="card h-100">
            <!-- Product image-->
            <img
              class="card-img-top"
              src={{"/gambar/".$lapangan->gambar}}
              alt="{{ $lapangan->nama_lapangan}}"
            />
            <!-- Product details-->
            <div class="card-body card-body-custom pt-4">
              <div>
                <!-- Product name-->
                <h3 class="fw-bolder text-primary">Deskripsi</h3>
                <p>
                  {{$lapangan->deskripsi}}
                </p>
                <div class="mobil-info-list border-top pt-4">
                    <h3>Fasilitas</h3>
                  <ul class="list-unstyled">
                    <li>
                      @if($lapangan->jaring)
                        <i class="ri-checkbox-circle-line"></i>
                        <span>Jaring</span>
                      @else
                        <i class="ri-close-circle-line text-secondary"></i>
                        <span>Jaring</span>
                      @endif
                    </li>
                    <li>
                      @if($lapangan->lampu)
                      <i class="ri-checkbox-circle-line"></i>
                      <span>Lampu</span>
                    @else
                    <i class="ri-close-circle-line text-secondary"></i>
                      <span>Lampu</span>
                    @endif
                    </li>
                    <li>
                      @if($lapangan->speaker)
                      <i class="ri-checkbox-circle-line"></i>
                      <span>Speaker</span>
                    @else
                    <i class="ri-close-circle-line text-secondary"></i>
                      <span>Speaker</span>
                    @endif
                    </li>
                    <li>
                      @if($lapangan->bola)
                      <i class="ri-checkbox-circle-line"></i>
                      <span>Bola</span>
                    @else
                    <i class="ri-close-circle-line text-secondary"></i>
                      <span>Bola</span>
                    @endif
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-4 mb-5">
          <div class="card">
            <!-- Product details-->
            <div class="card-body card-body-custom pt-4">
              <div class="text-center">
                <!-- Product name-->
                <div
                  class="d-flex justify-content-between align-items-center"
                >
                  <h5 class="fw-bolder">{{$lapangan->nama_lapangan}}</h5>
                  <div class="rent-price mb-3">
                    <span style="font-size: 1rem" class="text-primary"
                      >Rp.{{number_format ($lapangan->harga_sewa)}}/</span
                    >Jam
                  </div>
                </div>
                <ul class="list-unstyled list-style-group">
                  <li
                    class="border-bottom p-2 d-flex justify-content-between"
                  >
                    <span>Minuman</span>
                    <span style="font-weight: 600">{{$lapangan->minuman}}</span>
                  </li>
                  <li
                    class="border-bottom p-2 d-flex justify-content-between"
                  >
                    <span>Jumlah Lapangan</span>
                    <span style="font-weight: 600">{{$lapangan->jumlah_lapangan}}</span>
                  </li>
                  <li
                    class="border-bottom p-2 d-flex justify-content-between"
                  >
                    <span>Jenis Lapangan</span>
                    <span style="font-weight: 600">{{$lapangan->jenis_lapangan}}</span>
                  </li>
                </ul>
              </div>
            </div>
            <!-- Product actions-->
            <div class="card-footer border-top-0 bg-transparent">
              <div class="text-center">
                <a
                  class="btn d-flex align-items-center justify-content-center btn-primary mt-auto"
                  href="https://wa.link/20o7an"
                  style="column-gap: 0.4rem"
                  >Sewa Lapangan <i class="ri-whatsapp-line"></i
                ></a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
@endsection
