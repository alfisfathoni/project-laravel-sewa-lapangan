<?php

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\PesanController;
use App\Http\Controllers\MemberController;
use App\Http\Controllers\SessionController;
use App\Http\Controllers\DaftarPesanController;
use App\Http\Controllers\Admin\MessageController;
use App\Http\Controllers\Admin\LapanganController;
use App\Http\Controllers\Admin\DashboardController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [\App\Http\Controllers\HomeController::class, 'index'])->name('homepage');
Route::get('contact', [\App\Http\Controllers\HomeController::class, 'contact'])->name('contact');
Route::get('detail/{lapangan:slug}', [\App\Http\Controllers\HomeController::class, 'detail'])->name('detail');
Route::post('contact', [\App\Http\Controllers\HomeController::class, 'contactStore'])->name('contact.store');

Route::get('admin/dashboard', [\App\Http\Controllers\Admin\DashboardController::class, 'index'])->name('admin.dashboard.index');
Route::resource('admin/lapangans', \App\Http\Controllers\Admin\LapanganController::class);
Route::put('admin/lapangans/update-image/{id}', [\App\Http\Controllers\Admin\LapanganController::class, 'updateImage'])->name('admin.lapangans.updateImage');

Route::get('messages',[\App\Http\Controllers\Admin\MessageController::class, 'index'])->name('admin.messages.index');
Route::delete('messages/{message}',[\App\Http\Controllers\Admin\MessageController::class, 'destroy'])->name('messages.destroy');

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');

Route::get('/sesi',[SessionController::class, 'index']);
Route::post('/sesi/login',[SessionController::class, 'login']);
Route::get('/register',[SessionController::class, 'register']);
Route::post('/register/create',[SessionController::class, 'create']);
Route::get('/logout',[SessionController::class, 'logout']);

Route::get('member/dashboard', [MemberController::class, 'index']);
Route::resource('/pesan', PesanController::class);
Route::resource('/daftarpesan', DaftarPesanController::class);


Route::get('member/pesan', [MemberController::class, 'pesan']);
