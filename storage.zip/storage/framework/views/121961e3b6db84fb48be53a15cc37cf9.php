

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h3>Daftar Pesan</h3>
            
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama</th>
                            <th>Nomor Hp</th>
                            <th>Bukti Pembayaran</th>
                            <th>Lapangan</th>
                            <th>Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($no++); ?></td>
                                <td><?php echo e($item->nama); ?></td>
                                <td><?php echo e($item->no_hp); ?></td>
                                <td>
                                    <?php if($item->bukti_pembayaran): ?>

                                    <img src="<?php echo e(url('foto').'/'.$item->bukti_pembayaran); ?>" width="200" alt="">
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($item->lapangan); ?></td>
                                <td>Pending</td>
                            </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                         <td colspan="6" class="text-center">Data Kosong</td>
                                    </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\sewa-lapangan\resources\views/admin/daftarpesan/index.blade.php ENDPATH**/ ?>