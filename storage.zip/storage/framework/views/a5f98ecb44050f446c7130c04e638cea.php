

<?php $__env->startSection('content'); ?>
<header class="bg-dark py-5">
    <div class="container px-4 px-lg-5 my-5">
      <div class="text-center text-white">
        <h1 class="display-4 fw-bolder">Contact Kami</h1>
      </div>
    </div>
  </header>
  <!-- Section-->
  <section class="py-5">
    <div class="container px-4 px-lg-5 mt-5">

        <?php if(session()->has('message')): ?>
        <div class="alert alert-<?php echo e(session()->get('alert-type')); ?>  alert-dismissible fade show" role="alert">
          <?php echo e(session()->get('message')); ?>

        </div>
      <?php endif; ?>

      <?php if($errors->any()): ?>
        <div class="alert alert-danger">
           <ul>
               <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <li><?php echo e($error); ?></li>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
       <?php endif; ?>

      <div class="row justify-content-center">
        <div class="col-lg-10 m-auto">
          <div class="contact-form">
            <form action="<?php echo e(route('contact.store')); ?>" method="post">
                <?php echo csrf_field(); ?>
              <div class="row">
                <div class="col-lg-6 col-md-6 mb-2">
                  <div class="name-input form-group">
                    <input
                      type="text"
                      name="nama"
                      class="form-control"
                      placeholder="Isikan nama lengkap"
                      value="<?php echo e(old('nama')); ?>"
                    />
                  </div>
                </div>
                <div class="col-lg-6 col-md-6 mb-2">
                  <div class="email-input form-group">
                    <input
                      type="email"
                      name="email"
                      class="form-control"
                      placeholder="Isikan alamat email"
                      value="<?php echo e(old('email')); ?>"
                    />
                  </div>
                </div>
              </div>
              <div class="row">
                <div class="col-lg-12 col-md-6 mb-2">
                  <div class="subject-input form-group">
                    <input
                      type="text"
                      name="subject"
                      class="form-control"
                      placeholder="Isikan subject email"
                      value="<?php echo e(old('subject')); ?>"
                    />
                  </div>
                </div>
              </div>
              <div class="message-input form-group mb-3">
                <textarea
                  name="pesan"
                  cols="30"
                  rows="10"
                  placeholder="Isikan pesan anda"
                  class="form-control"
                ><?php echo e(old('pesan')); ?></textarea>
              </div>

              

              <div class="input-submit form-group">
                <button
                  type="submit"
                  style="height: 50px; width: 400px; margin: 0 auto"
                  class="d-block btn btn-primary"
                >
                  Kirim Pesan
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\sewa-lapangan\resources\views/frontend/contact.blade.php ENDPATH**/ ?>