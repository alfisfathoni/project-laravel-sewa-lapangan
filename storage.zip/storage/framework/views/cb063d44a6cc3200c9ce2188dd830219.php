

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            Form Tambah Pesanan
        </div>
        <div class="card-body">
            <form action="/pesan" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="nama_lapangan">Nama </label>
                    <input type="text" name="nama" class="form-control" value="<?php echo e(old('nama')); ?>">
                </div>
                <div class="form-group">
                    <label for="harga_sewa">Nomor Hp</label>
                    <input type="number" name="no_hp" class="form-control" value="<?php echo e(old('nomor_hp')); ?>">
                </div>
                <div class="form-group">
                    <label for="lapangan">Lapangan</label><br>
                    <input type="radio" name="lapangan" class="form" value="Futsal" required="required"> Futsal <br>
                    <input type="radio" name="lapangan" class="form"value="Badminton" required="required"> Badminton <br>
                    <input type="radio" name="lapangan" class="form" value="Basket" required="required"> Basket <br>
                    <input type="radio" name="lapangan" class="form"value="Tenis" required="required"> Tenis <br>
                </div>
                <div class="form-group">
                    <label for="gambar">Bukti Pembayaran</label>
                    <input type="file" class="form-control" name="foto">
                </div>
                <div class="form-group">
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.member', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\sewa-lapangan\resources\views/pesan/create.blade.php ENDPATH**/ ?>