

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h3>Daftar Pesan Lapangan</h3>
            <a href="/pesan/create" class="btn btn-primary">Tambah Pesan</a>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered">
                                <?php if(session()->has('message')): ?>
                    <div class="alert alert-<?php echo e(session()->get('alert-type')); ?>  alert-dismissible fade show" role="alert">
                        <?php echo e(session()->get('message')); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                          <span aria-hidden="true">&times;</span>
                        </button>
                      </div>
                    <?php endif; ?>
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                             <ul>
                                 <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                   <li><?php echo e($error); ?></li>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </ul>
                        </div>
                    <?php endif; ?>
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama</th>
                            <th>Nomor Hp</th>
                            <th>Bukti Pembayaran</th>
                            <th>Lapangan</th>
                            <th>Status</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($no++); ?></td>
                                <td><?php echo e($item->nama); ?></td>
                                <td><?php echo e($item->no_hp); ?></td>
                                <td>
                                    <?php if($item->bukti_pembayaran): ?>

                                    <img src="<?php echo e(url('foto').'/'.$item->bukti_pembayaran); ?>" width="200" alt="">
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($item->lapangan); ?></td>
                                <td>Pending</td>
                                <td>
                                    <a href="<?php echo e(url('/pesan/'.$item->id.'/edit')); ?>" class="btn btn-sm btn-warning">Edit</a>
                                    <form onclick="return confirm('Anda Yakin Menghapus Data?');" class="d-inline" action="<?php echo e('/pesan/'.$item->id); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <button type="submit" class="btn btn-danger btn-sm">Delete</button>
                                    </form>
                                </td>
                                
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                 <td colspan="6" class="text-center">Data Kosong</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.member', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laravel\sewa-lapangan\resources\views/pesan/index.blade.php ENDPATH**/ ?>